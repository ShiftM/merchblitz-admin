<template>
    <div class="container-fluid animated fadeIn h-100">
        <div class="row">
            <div class="col-lg-12 mt-4">
                <router-view/>       
            </div>
        </div>
    </div>
</template>
