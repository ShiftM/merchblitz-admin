<template>
    <div class="error-page text-center">
        <div class="container-fluid animated fadeIn h-100 p-0">
            <div class="row w-100 m-0">
                <div class="col-lg-12 p-0 m-0 error-header">
                    <h2>404</h2>
                </div>
                <div class="col-lg-12 px-0 py-5 m-0 error-body">
                    <h3>Oops! Page Not Found.</h3>
                    <p>Sorry, the page you are looking for does not exist or have been removed already.</p>
                    <a href="/events" class="btn btn-outline-primary">Go to Home</a>
                </div>  
            </div>
        </div>
    </div>
</template>
